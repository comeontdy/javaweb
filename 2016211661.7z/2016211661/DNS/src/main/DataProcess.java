package main;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class DataProcess implements Runnable {
    private int level = 0;
    private String fileName = "cache.txt";
    private String dnsIP = "114.114.114.114";


    //报文处理，（解析和封装）
    private byte[] data;
    private int dataLength;
    private InetAddress clientAddress;
    private int clientPort;

    public void setLevel(int level) {
        this.level = level;
    }

    public void setDnsIP(String dnsIP) {
        this.dnsIP = dnsIP;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public DataProcess(DatagramPacket packet){
        //报文读取
        data = new byte[packet.getLength()];
        System.arraycopy(packet.getData(), 0, data, 0, packet.getLength());
        dataLength = packet.getLength();
        clientAddress = packet.getAddress();
        clientPort = packet.getPort();
    }

    /**
     * DNS报文格式
     * +-----------------------------+
     * \        Header（固定头部）   \
     * +-----------------------------+
     * \        Question(问题)       \
     * +-----------------------------+
     * \       Answer（回答问题的RRs)\
     * +-----------------------------+
     * \    Authority(指向权威的RRs) \
     * +-----------------------------+
     * \    Additional(附加信息RRs)  \
     * +-----------------------------+
     */
    public void run(){
        int tag = 0;
        byte[] tempByte = new byte[2];
        Header header = new Header();
        Question question = new Question();

        try{
            //报文头部解析
            for (int i = 0; i < 2; i++) {
                tempByte[i] = data[tag + i];
            }
            header.setID(Tools.byteArrayToShort(tempByte));
            tag += 2;

            for (int i = 0; i < 2; i++){
                tempByte[i] = data[tag + i];
            }
            header.setFlags(Tools.byteArrayToShort(tempByte));
            tag += 2;

            for (int i = 0; i < 2; i++){
                tempByte[i] = data[tag + i];
            }
            header.setQdcount(Tools.byteArrayToShort(tempByte));
            tag += 2;

            for (int i = 0; i < 2; i++){
                tempByte[i] = data[tag + i];
            }
            header.setAncount(Tools.byteArrayToShort(tempByte));
            tag += 2;

            for (int i = 0; i < 2; i++){
                tempByte[i] = data[tag + i];
            }
            header.setNscount(Tools.byteArrayToShort(tempByte));
            tag += 2;

            for (int i = 0; i < 2; i++){
                tempByte[i] = data[tag + i];
            }
            tag += 2;
            header.setArcount(Tools.byteArrayToShort(tempByte));

            //解析要查询的question部分（域名）
            if (header.getQdcount() > 0 ) { //Qcount为问题个数
                String qname = Tools.byteArrayToString1(data, tag, (byte)0x00);
                question.setQname(qname);

                tag += qname.length() + 2;
                for (int i = 0; i < 2; i++) {
                    tempByte[i] = data[tag + i];
                }
                question.setQtype(Tools.byteArrayToShort(tempByte));

                tag += 2;
                for (int i = 0; i < 2; i++) {
                    tempByte[i] = data[tag + i];
                }
                question.setQclass(Tools.byteArrayToShort(tempByte));
            } else {
                System.out.println(" 数据长度不匹配！");
            }
        }catch (ArrayIndexOutOfBoundsException e){
            e.printStackTrace();
        }

        ArrayList<String> ipList = Tools.getIpMap1(fileName).getOrDefault(question.getQname(),new ArrayList<>());

        if ( !ipList.isEmpty() && question.getQtype() == 1) {
            //System.out.println("getQtype111111:"+ question.getQtype());
            //构建header
            short flags = 0;

            //判断域名是否合法
            if (!ipList.get(0).equals("0.0.0.0")) { //recode = 0，响应报文没有差错
                flags = (short) 0x8580; //1000010110000000
            }else { //recode = 3，响应报文名字差错，表示在查询中指定域名不存在
                flags = (short) 0x8583; //1000010110000011
            }
            //构建头部，其中后三部分，除了附加信息资源格式个数为0，其他都为1
            Header responseHeader = new Header(header.getID(), flags, header.getQdcount(), (short) ipList.size(), (short)1 , (short) 0);
            byte[] headerByteArray = responseHeader.toByteArray();
            //构建question
            byte[] quesionByteArray = question.toByteArray();
            //构建Answer，指向的域名采用消息压缩模式0xc00c表示1100000000001100
            ArrayList<RRs> answerRRs = new ArrayList<>();
            ArrayList<byte[]> RRsByteArrays = new ArrayList<>();
            for(String ip : ipList) {
                RRs responseRRs = new RRs((short) 0xc00c, question.getQtype(), question.getQclass(), 86400, (short)4, ip);
                byte[] RRsByteArray = responseRRs.toByteArray();
                answerRRs.add(responseRRs);
                RRsByteArrays.add(RRsByteArray);
            }
            //构建authorityRRs格式，指向权威的RRs格式
            RRs responseAu = new RRs((short) 0xc00c, (short) 6, question.getQclass(), 86400, (short) 0 , null);
            byte[] authorityRRsByteArray = responseAu.toByteArray();

            //构建完整的response包
            byte[] responsePacket = new byte[headerByteArray.length + quesionByteArray.length + RRsByteArrays.get(0).length * answerRRs.size() + authorityRRsByteArray.length];
            int offset = 0;
            for (int i = 0; i < headerByteArray.length; i++) {
                responsePacket[offset++] = headerByteArray[i];
            }
            for (int i = 0; i < quesionByteArray.length; i++) {
                responsePacket[offset++] = quesionByteArray[i];
            }
            if (!ipList.get(0).equals("0.0.0.0")) {
                switch (level) {
                    case 0:
                        System.out.println("查询成功！");
                        break;
                    case 1:
                        System.out.println("查询成功！");
                        System.out.println("要查询的域名:" + question.getQname());
                        System.out.println("查询域名的ip地址:" + ipList.get(0) + "  " + ipList.get(1));
                        break;
                    case 2:
                        System.out.println("查询成功！");
                        System.out.println("客户端IP地址：127.0.0.1");
                        System.out.println("要查询的问题个数：1");
                        System.out.println("要查询的问题类型：A");
                        System.out.println("要查询的域名:" + question.getQname());
                        System.out.println("查询域名的ip地址:" + ipList.get(0) + "  " + ipList.get(1));
                        break;
                }

                for (byte[] RRsByteArray : RRsByteArrays ) {
                    for (int i = 0; i < RRsByteArray.length; i++) {
                        responsePacket[offset++] = RRsByteArray[i];
                    }
                }
            } else{
                System.out.println("查询失败（不良网站）！");
                System.out.println("要查询的域名:" + question.getQname());
            }
            for (int i = 0; i < authorityRRsByteArray.length; i++) {
                responsePacket[offset++] = authorityRRsByteArray[i];
            }

            //根据文件内容构建回复包packet
            DatagramPacket packet = new DatagramPacket(responsePacket, responsePacket.length, clientAddress,clientPort);

            synchronized (Server.lock) {//线程同步，挂锁
                try {
                    Server.getSocket().send(packet);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {  //请求外部服务器
            try {
                InetAddress dnsServerAddress = InetAddress.getByName(dnsIP);
                //InetAddress dnsServerAddress = InetAddress.getByName("10.128.247.56");
                //InetAddress dnsServerAddress = InetAddress.getByName("169.254.190.107");
                //重构从本地接受过来的packet
                DatagramPacket internetSendPacket = new DatagramPacket(data, dataLength, dnsServerAddress, 53);
                //第二个socket对象，用来从dns到外部服务器之间的联系
                DatagramSocket internetSocket = new DatagramSocket();
                internetSocket.send(internetSendPacket);

                byte[] receiveData = new byte[1024];
                DatagramPacket reciveInternetPacket = new DatagramPacket(receiveData, receiveData.length);
                internetSocket.receive(reciveInternetPacket);
                //重构从外部服务器接收过来的packet
                DatagramPacket responseInternetPacket = new DatagramPacket(receiveData, reciveInternetPacket.getLength(), clientAddress, clientPort);
                internetSocket.close();

                synchronized (Server.lock) {//线程同步，挂锁
                    try {
                        Server.getSocket().send(responseInternetPacket);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
