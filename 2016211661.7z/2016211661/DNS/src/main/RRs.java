package main;

public class RRs {
    /**
     * 资源记录格式
                                   1  1  1  1  1  1
     0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     |					   ... 						  |
     |                    NAME                       |
     |                    ...                        |
     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     |                    TYPE                       |
     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     |                    CLASS                      |
     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     |                    TTL                        |
     |                                               |
     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     |                    RDLENGTH                   |
     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     |                    ...                        |
     |                    RDATA                      |
     |                    ...                        |
     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     */

    private short rname;//资源匹配的域名（补丁长度）采用消息压缩，2字节
    private short rtype; //资源记录类型（2字节）
    private short rclass; //Rdata数据中的类（2字节）
    private int rttl; //缓存时间（4字节）
    private short rdlength; //规定RDATA数据中的长度（2字节）
    private String rdata;//描述资源，当type是A，class是IN的时候4字节，表示互联网地址

    public RRs(){

    }
    public RRs(short rname, short rtype, short rclass, int rttl, short rdlength, String rdata){
        this.rname = rname;
        this.rtype = rtype;
        this.rclass = rclass;
        this.rttl = rttl;
        this.rdlength = rdlength;
        this.rdata = rdata;
    }

    public short getRname() {
        return rname;
    }
    public short getRtype() {
        return rtype;
    }
    public short getRclass() {
        return rclass;
    }
    public int getRttl() {
        return rttl;
    }
    public short getRdlength() {
        return rdlength;
    }
    public String getRdata() {
        return rdata;
    }

    public void setRname(short rname) {
        this.rname = rname;
    }
    public void setRtype(short rtype) {
        this.rtype = rtype;
    }
    public void setRclass(short rclass) {
        this.rclass = rclass;
    }
    public void setRttl(int rttl) {
        this.rttl = rttl;
    }
    public void setRdlength(short rdlength) {
        this.rdlength = rdlength;
    }
    public void setRdata(String rdata) {
        this.rdata = rdata;
    }

    public byte[] toByteArray(){
        byte[] rrs = new byte[12 + rdlength];
        int tag = 0;
        byte[] name = Tools.shortToByteArray(rname);
        for(int i = 0; i < 2; i++){
            rrs[tag++] = name[i];
        }

        byte[] type = Tools.shortToByteArray(rtype);
        for(int i = 0; i < 2; i++){
            rrs[tag++] = type[i];
        }

        byte[] class1 = Tools.shortToByteArray(rclass);
        for(int i = 0; i < 2; i++){
            rrs[tag++] = class1[i];
        }

        byte[] ttl = Tools.intToByteArray(rttl);
        for(int i = 0; i < 4; i++){
            rrs[tag++] = ttl[i];
        }

        byte[] length = Tools.shortToByteArray(rdlength);
        for(int i = 0; i < 2; i++){
            rrs[tag++] = length[i];
        }
        if(rdlength == 4) {
            byte[] data = Tools.ipv4ToByteArray(rdata);
            for(int i = 0; i < 4; i++){
                rrs[tag++] = data[i];
            }
        }
        return rrs;
    }
}

