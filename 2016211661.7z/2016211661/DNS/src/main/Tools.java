package main;

//import com.sun.org.apache.xpath.internal.operations.String;
import java.io.*;
import java.lang.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Tools {

    /*short型和byte[]型之间的转换*/
    public static byte[] shortToByteArray(short a){
        //高字节在前，低字节在后
        byte[] result = new byte[2];
        result[0] = (byte)((a >> 8) & 0xFF);
        result[1] = (byte)(a & 0xFF);
        return result;
    }
    public static short byteArrayToShort(byte[] a){
        return (short) (((a[0] & 0xFF) << 8) | a[1] & 0xFF);
    }


    /*int类型和byte[]类型之间的转换*/
    public static byte[] intToByteArray(int a) {
        byte[] result = new byte[4];
        //高位到低位
        result[0] = (byte)((a >> 24) & 0xFF);
        result[1] = (byte)((a >> 16) & 0xFF);
        result[2] = (byte)((a >> 8) & 0xFF);
        result[3] = (byte)(a & 0xFF);

        return result;
    }
    public static int byteArrayToInt(byte[] a, int offset){
        int value= 0;
        //由高位到低位
        for (int i = 0; i < 4; i++) {
            int shift= (4 - 1 - i) * 8;
            value +=(a[i] & 0x000000FF) << shift;//往高位游
        }
        return value;
    }


    /*byte[]和String类型之间的转换*/
    public static byte[] stringToByteArray1(String a) {
        //System.out.println("要查询的域名:" + a);
        String[] str = a.split("\\.");
        byte[] temp = new byte[a.length() + 2];
        int i = 0;

        for(String s : str) {
            temp[i++] = (byte) s.length();
            for (char c : s.toCharArray()) {
                temp[i++] = (byte)c;
            }
        }

        temp[i++] = 0x00;
        return temp;
    }
    public  static String byteArrayToString1(byte[] a, int start, byte end){
        StringBuilder string = new StringBuilder();
        int i = 0;
        while(start < a.length && a[start] != end) {
            //System.out.println("a[i]:"+a[start]);
            byte b = a[start++];
            i = b >= 0 ? b : 256 + b;
            //System.out.println("i:"+ i);
            byte[] temp = new byte[i];
            System.arraycopy(a, start, temp, 0, i);
            string.append(new String(temp));
            start += i;
            //System.out.println("start:"+start);
            if (start < a.length && a[start] != end){
                string.append(".");
            }
        }
        return string.toString();
    }


    /*String类型转化成byte[]类型*/
    public static byte[] stringToByteArray(String a){
        //return a.getBytes();

        byte[] temp = new byte[a.length() + 2];
        System.arraycopy(a.getBytes(), 0, temp, 0, a.length());
        temp[a.length()] = (byte) 0x00;

        return temp;
    }
    public static String byteArrayToString(byte[] a, int start, byte end) {
        //String str = new String();
        int stringNum = 0;
        int num = start;
        while(a.length > num && a[num] != end) {
            stringNum += 1;
            num += 1;
        }
        byte[] temp = new byte[stringNum];
        System.arraycopy(a, start, temp, 0, stringNum);
        String result = new String(temp);
        return result;
    }


    /*域名和string之间的转换*/
    public static byte[] ipv4ToByteArray(String ipv4) {
        if(ipv4 == null) {
            return null;
        }
        byte[] result = new byte[4];
        String[] ipv4SubArray = ipv4.split("\\.");
        if (ipv4SubArray.length != 4) {
            System.out.println("不是合法的IPv4地址");
            return null;
        }
        for (int i=0; i<ipv4SubArray.length; i++) {
            int num = Integer.parseInt(ipv4SubArray[i]);
            byte tmp = 0;
            if (num > 127) {
                tmp = (byte)(num - 256);
            } else {
                tmp = (byte)num;
            }
            result[i] = tmp;
        }
        return result;
    }


    /*设置和获取相应文件内容*/
    public static Map<String,String> getIpMap(String fileName) {
        File file = new File(fileName);
        Map<String ,String> tempIp = new HashMap<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = null;
            while ((line = br.readLine()) != null) {
                String[] list = line.split(" ");
                tempIp.put(list[0] , list[1]);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tempIp;
    }
    public static Map<String,ArrayList<String>> getIpMap1(String fileName) {
        File file = new File(fileName);
        Map<String ,ArrayList<String>> tempIp = new HashMap<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = null;
            while ((line = br.readLine()) != null) {
                String[] list = line.split(" ");
                ArrayList<String> tempList = new ArrayList<>();
                for(int i = 1; i < list.length; i++) {
                    tempList.add(list[i]);
                }
                tempIp.put(list[0] , tempList);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tempIp;
    }
    public static void setIpMap(String domain, ArrayList<String> list) {
        File file = new File("cache.txt");
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(file,true));
            String line = domain;
            for(String s : list) {
                line += " " + s;
            }
            line = line + "\n";
            bw.write(line);
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
