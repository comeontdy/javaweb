package main;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.*;
import java.io.BufferedReader;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class Server {
    private static DatagramSocket socket;

    static final Object lock = new Object();

    public static DatagramSocket getSocket() {
        return socket;
    }

    public static void main(String[] args ) {
        String fileName = "";
        String dnsIP = "";
        System.out.println("请输入要调试信息的级别（0：无调试信息，1：调试信息级别1，2：调试信息级别2！）：");
        Scanner s = new Scanner(System.in);
        int level = s.nextInt();
        switch (level){
            case 0:
                System.out.println("您选择的是无调试信息！");
                break;
            case 1:
                System.out.println("您选择的是调试信息级别1！");
                System.out.println("请输本地数据库名：");
                Scanner s1 = new Scanner(System.in);
                fileName = s1.nextLine();
                break;
            case 2:
                System.out.println("您选择的是调试信息级别2！");
                System.out.println("请输入本地数据库名： ");
                Scanner s2 = new Scanner(System.in);
                fileName = s2.nextLine();
                System.out.println("请输入外部dns服务器的IP地址：");
                Scanner s3 = new Scanner(System.in);
                dnsIP = s3.nextLine();
                break;
            default:
                System.out.println("指令不正确！(默认无调试！)");
                break;
        }

        byte[] data = new byte[1024];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        //创建线程池
        ExecutorService servicePool = Executors.newFixedThreadPool(10);

        try {
            socket = new DatagramSocket(53);
        } catch (SocketException e) {
            e.printStackTrace();
        }

        while (true) {

            try {
                socket.receive(packet);
            } catch (IOException e) {
                e.printStackTrace();
            }

            switch (level) {
                case 0:
                    DataProcess d = new DataProcess(packet);
                    d.setLevel(0);
                    servicePool.execute(d);
                    break;
                case 1:
                    DataProcess d1 = new DataProcess(packet);
                    d1.setLevel(1);
                    d1.setFileName(fileName);
                    servicePool.execute(d1);
                    break;
                case 2:
                    DataProcess d2 = new DataProcess(packet);
                    d2.setLevel(2);
                    d2.setFileName(fileName);
                    d2.setDnsIP(dnsIP);
                    servicePool.execute(d2);
                    break;
            }
            //servicePool.execute(new DataProcess(packet));
        }
    }
}
