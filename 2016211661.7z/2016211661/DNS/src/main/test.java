package main;

import java.util.*;

public class test{
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int m = s.nextInt();
        int n = s.nextInt();
        Scanner s1 = new Scanner(System.in);
        int[] index = new int[2];
        char[][] inputGroup = new char[m][n];
        for(int i = 0; i < m; i++) {
            String temp = s1.nextLine();
            for(int j = 0; j < n; j++) {
                char t = temp.charAt(j);
                if(t-'0' == 2) {
                    index[0] = i;
                    index[1] = j;
                }
                inputGroup[i][j] = temp.charAt(j);
            }
        }
        System.out.println(minLength(inputGroup,index));
    }

    public static int minLength(char[][] g, int[] index){
        int res = 0;
        int[][] dir = {{-1,0},{1,0},{0,-1},{0,1}};
        boolean[][][] isVisited = new boolean[g.length][g[0].length][1024];

        isVisited[index[0]][index[1]][0] = true;
        Queue<Integer> queue = new LinkedList<>();
        queue.offer(index[0]); queue.offer(index[1]); queue.offer(0);
        while(!queue.isEmpty()) {
            int num = queue.size()/3;
            res += 1;
            while(num > 0) {
                int Y0 = queue.poll();
                int X0 = queue.poll();
                int k = queue.poll();
                num -- ;
                for (int i = 0; i < 4; i++) {
                    int Y = Y0 + dir[i][0];
                    int X = X0 + dir[i][1];
                    int key = k;
                    if(Y<0 || Y >= g.length || X < 0 || X >= g[0].length || g[Y][X]-'0' == 0)
                        continue;
                    else if(g[Y][X] - '0' ==  3){
                        return res;
                    }else if(g[Y][X] >= 'a' && g[Y][X] <= 'j'){
                        key = key | 1 << g[Y][X]-'a';
                    }else if(g[Y][X] >= 'A' && g[Y][X] <= 'J' && (key & 1 << g[Y][X]-'A') == 0){
                        continue;
                    }
                    if (isVisited[Y][X][key] == false) {
                        isVisited[Y][X][key] = true;
                        queue.offer(Y);
                        queue.offer(X);
                        queue.offer(key);
                    }
                }
            }

        }
        return -1;
    }
}