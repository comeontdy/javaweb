package main;

public class Header {
    /**
    /*UDP报文的header格式（一共12字节）
                                     1  1   1   1   1
       0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
	  |                      ID                       |
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
	  |QR|  Opcode   |AA|TC|RD|RA|   Z    |   RCODE   |
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
	  |                    QDCOUNT                    |
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
	  |                    ANCOUNT                    |
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
	  |                    NSCOUNT                    |
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
	  |                    ARCOUNT                    |
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     */

    private short ID; //标识(两字节，下同)
    private short flags;//flags
    private short qdcount; //question section的问题个数
    private short ancount; //answer section 的RR个数
    private short nscount; //authority records section的RR个数
    private short arcount; //additional records section的RR个数

    public Header(){

    }
    public Header(short ID, short flags, short qdcount, short ancount, short nscount, short arcount){
        this.ID = ID;
        this.flags = flags;
        this.qdcount = qdcount;
        this.ancount = ancount;
        this.nscount = nscount;
        this.arcount = arcount;
    }

    public short getID() {
        return ID;
    }

    public short getFlags() {
        return flags;
    }

    public short getAncount() {
        return ancount;
    }

    public short getQdcount() {
        return qdcount;
    }

    public short getNscount() {
        return nscount;
    }

    public short getArcount() {
        return arcount;
    }

    public void setID(short ID) {
        this.ID = ID;
    }

    public void setQdcount(short qdcount) {
        this.qdcount = qdcount;
    }

    public void setFlags(short flags) {
        this.flags = flags;
    }

    public void setAncount(short ancount) {
        this.ancount = ancount;
    }

    public void setNscount(short nscount) {
        this.nscount = nscount;
    }

    public void setArcount(short arcount) {
        this.arcount = arcount;
    }

    public byte[] toByteArray(){
        byte[] header = new byte[12];
        int tag = 0;

        byte[] tempByte = new byte[2];
        tempByte = Tools.shortToByteArray(ID);
        for(int i = 0; i < tempByte.length; i++){
            header[tag++] = tempByte[i];
        }

        tempByte = Tools.shortToByteArray(flags);
        for(int i = 0; i < tempByte.length; i++){
            header[tag++] = tempByte[i];
        }

        tempByte = Tools.shortToByteArray(qdcount);
        for(int i = 0; i < tempByte.length; i++){
            header[tag++] = tempByte[i];
        }

        tempByte = Tools.shortToByteArray(ancount);
        for(int i = 0; i < tempByte.length; i++){
            header[tag++] = tempByte[i];
        }

        tempByte = Tools.shortToByteArray(nscount);
        for(int i = 0; i < tempByte.length; i++){
            header[tag++] = tempByte[i];
        }

        tempByte = Tools.shortToByteArray(arcount);
        for(int i = 0; i < tempByte.length; i++){
            header[tag++] = tempByte[i];
        }

        return header;
    }
}
