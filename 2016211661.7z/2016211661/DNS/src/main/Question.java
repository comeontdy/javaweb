package main;

public class Question {
    /**
    * UDP传输报文Question格式
    *                                 1  1  1  1  1  1
		0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
	  |                                               |
	  |                    QNAME                      |
	  |                    ```                        |
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
	  |                    QTYPE                      |
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
	  |                    QCLASS                     |
	  +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     */

    private String qname; //用标签序列表示的域名
    private short qtype; //类型(2字节)
    private short qclass; //qclass（2字节，固定为1，表示“IN”,代表互联网）

    public Question(){

    }
    public Question(String qname, short qtype, short qclass){
        this.qname = qname;
        this.qtype = qtype;
        this.qclass = qclass;
    }

    public String getQname() {
        return qname;
    }
    public short getQtype() {
        return qtype;
    }
    public short getQclass() {
        return qclass;
    }

    public void setQname(String qname) {
        this.qname = qname;
    }
    public void setQtype(short qtype) {
        this.qtype = qtype;
    }
    public void setQclass(short qclass) {
        this.qclass = qclass;
    }

    public byte[] toByteArray(){
        byte[] question = new byte[qname.length() + 2 + 4 ]; //name后1位为结束标识位
        int tag = 0;

        byte[] name = Tools.stringToByteArray1(qname);
        for(int i = 0; i < name.length; i++){
            question[tag++] = name[i];
        }

        byte[] type = Tools.shortToByteArray(qtype);
        for(int i = 0; i < 2; i++){
            question[tag++] = type[i];
        }

        byte[] class1 = Tools.shortToByteArray(qclass);
        for(int i = 0; i < 2; i++){
            question[tag++] = class1[i];
        }

        return question;
    }
}